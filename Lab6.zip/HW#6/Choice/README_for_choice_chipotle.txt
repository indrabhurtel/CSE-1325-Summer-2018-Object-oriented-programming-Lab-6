Indra Bhurtel

***README***

I have selected chipotle program to create in GUI.

Files included: choice.cpp, choice.h, choiceChipotle.cpp, and makefile
--------------------------

1. The program contains four  files i.e. choice.cpp, choice.h, choiceChipotle.cpp, and makefile
2. choiceChipotle.cpp contains the definations for all the functions being used.
3. choice.h has the function prototypes.
4. choice.cpp has our main.
5. makefile has the necessary command for the program compilation which help to speed up the compile process.

Compilation instructions:
--------------------------------------------

Go to the destination folder where all the four files are located.
Then in the command window, type the following command. 
make ( make sure 'm' is not capitalized)
./choice ( make sure 'c' is not capitalized)

When run:
------------------

When run, program will pop up a window showing "Apply", "Customer", and "Exit" buttons.
When "Apply" button is clicked, it will ask for the full name of a delivery person who is applying for the job of delivery driver. 
When full name is entered, then the program will save the name of delivery person.
When "Customer" button is clicked, it will ask to choice the different items from the menu.
When all items are chosen, it will show the chosen items and ask for the order confirmation.
And when order is confirmed, it will show the name of delivery driver.
When "Exit" button is clicked, the program exits.